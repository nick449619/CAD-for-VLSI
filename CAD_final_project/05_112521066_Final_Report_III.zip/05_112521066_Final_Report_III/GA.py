import random
import parseYOSYS
import parseLib
import generate_GA_result
import subprocess

def parser():

    verilog_input_file = 'output_opt.v'
    verilog_output_file = 'output_opt_done.v'
    lib_file = 'lib1.json'

    encountered_gates = parseYOSYS.process_verilog_file(verilog_input_file, verilog_output_file)

    logic_gate_count = parseLib.parse_lib_file(lib_file)

    encountered_gates_counts = [logic_gate_count.get(gate.upper(), 0) for gate in encountered_gates]

    print("Encountered gates:", encountered_gates)
    print("Gate counts:", encountered_gates_counts)
    return encountered_gates_counts

GENOME_LIMITS = parser()

POPULATION_SIZE = 200
GENOME_LENGTH = len(GENOME_LIMITS)
MUTATION_RATE = 0.1
GENERATIONS = 1000

def initialize_population():
    population = [[random.randint(1, GENOME_LIMITS[i]) for i in range(GENOME_LENGTH)] for _ in range(POPULATION_SIZE)]
    print("Initialized Population:")
    for genome in population:
        print(genome)
    return population
def calculate_fitness(genome):
    generate_GA_result.process_verilog_file('test.v','GA_temp.v',genome)
    # 將 genome 作為參數傳遞給 ./cost 程式
    command2 = "./cost_estimator_1 -library lib1.json -netlist GA_temp.v -output cost.txt" 
    # “./cost_function_1 -library low_vt.lib -netlist design_iter0008.v -output cost_0008.txt”
    # 使用 subprocess 執行命令，並等待其完成
    try:
        process = subprocess.run(command2, check=True)
        process.wait()  # 等待子進程完成
    except subprocess.CalledProcessError as e:
        print(f"Error while executing './cost': {e}")
        return float('inf')  # 返回一個大數作為 fitness，表示出錯

    # 讀取 cost.txt 中的值作為 fitness
    try:
        with open('cost.txt', 'r') as f:
            fitness_value = 1/float(f.read().strip())
    except FileNotFoundError:
        print("Error: 'cost.txt' file not found.")
        return float('inf')  # 返回一個大數作為 fitness，表示找不到檔案
    except ValueError:
        print("Error: 'cost.txt' file does not contain a valid number.")
        return float('inf')  # 返回一個大數作為 fitness，表示檔案內容不是有效數字

    return fitness_value


def selection(population, fitnesses):
    total_fitness = sum(fitnesses)
    probabilities = [f / total_fitness for f in fitnesses]
    selected_indices = random.choices(range(POPULATION_SIZE), probabilities, k=POPULATION_SIZE)
    return [population[i] for i in selected_indices]

def crossover(parent1, parent2):
    crossover_point = random.randint(1, GENOME_LENGTH - 1)
    child1 = parent1[:crossover_point] + parent2[crossover_point:]
    child2 = parent2[:crossover_point] + parent1[crossover_point:]
    return child1, child2

def mutate(genome):
    for i in range(GENOME_LENGTH):
        if random.random() < MUTATION_RATE:
            genome[i] = random.randint(1, GENOME_LIMITS[i])
    return genome


def genetic_algorithm():
    population = initialize_population()

    for generation in range(GENERATIONS):
        fitnesses = [calculate_fitness(genome) for genome in population]
        population = selection(population, fitnesses)

        new_population = []
        for i in range(0, POPULATION_SIZE, 2):
            parent1 = population[i]
            parent2 = population[i + 1]
            child1, child2 = crossover(parent1, parent2)
            new_population.append(mutate(child1))
            new_population.append(mutate(child2))
        
        population = new_population
        best_fitness = max(fitnesses)
        print(f'Generation {generation + 1}, Best Fitness: {best_fitness}')

    best_genome = max(population, key = calculate_fitness)
    return best_genome

best_solution = genetic_algorithm()
generate_GA_result.process_verilog_file('output_opt_done.v','test.v',best_solution)
print('Best Solution:', best_solution)
