import re
import subprocess

def remove_second_underscore_number(s):
    pattern = r'(_\d+)'  
    matches = re.finditer(pattern, s)
    match_positions = [(match.start(), match.end()) for match in matches]
   
    if len(match_positions) < 2:
        return s
    
    second_start, second_end = match_positions[1]
    result = s[:second_start] + s[second_end:]
    return result

def process_verilog_line(line, numbers, number_index):

    gate_types = ['not', 'or', 'nor', 'and', 'nand', 'xor', 'xnor', 'buf']
    
    if any(line.strip().startswith(gate_type) for gate_type in gate_types):
        gate_match = re.match(r'([a-zA-Z]+)', line.strip())
        
        if gate_match:
            number = numbers[number_index]
            number_index += 1
            gate_type = gate_match.group(1)
            new_gate_type = gate_type + '_' + str(number)
            line = line.replace(gate_match.group(0), new_gate_type, 1)
            line = remove_second_underscore_number(line)
            
    return line,number_index

def process_verilog_file(input_file, output_file, numbers):
    with open(input_file, 'r') as infile, open(output_file, 'w') as outfile:
        number_index = 0
        for line in infile:
            processed_line, number_index = process_verilog_line(line, numbers, number_index)
            outfile.write(processed_line)



