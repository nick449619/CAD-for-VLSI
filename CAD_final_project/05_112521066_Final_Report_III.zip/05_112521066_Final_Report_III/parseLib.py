# parseLib.py
import json
from collections import defaultdict

def parse_lib_file(lib_file):
    with open(lib_file, 'r') as file:
        data = json.load(file)

    logic_gate_count = defaultdict(int)

    for cell in data['cells']:
        cell_type = cell['cell_type'].upper() 
        logic_gate_count[cell_type] += 1

    return dict(logic_gate_count)


