# parseYOSYS.py
import re

# 全局数组用于存储遇到的逻辑门类型
encountered_gates = []

def process_verilog_line(line):
    global encountered_gates
    # 检查行是否以 `\$_` 开头
    if line.strip().startswith(r'\$_'):
        # 去掉行中的 `\$_`
        line = line.replace(r'\$_', '', 1)
        # 查找门类型 (例如：NOT, OR, XOR等)
        gate_match = re.match(r'(\w+)', line.strip())
        if gate_match:
            gate_type = gate_match.group(1)
            # 转换门类型为小写并在末尾加 `1`
            new_gate_type = gate_type.lower() + '1'
            line = line.replace(gate_type, new_gate_type, 1)
            # 将遇到的门类型加入全局数组，转换为小写并去掉下划线
            encountered_gates.append(gate_type.lower().replace('_', ''))
    return line

def process_verilog_file(input_file, output_file):
    global encountered_gates
    encountered_gates = []
    with open(input_file, 'r') as infile, open(output_file, 'w') as outfile:
        for line in infile:
            processed_line = process_verilog_line(line)
            outfile.write(processed_line)
    return encountered_gates
